﻿using Microsoft.EntityFrameworkCore;
using TicketingMvc.Models;

namespace TicketingMvc.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Location> Locations { get; set; }
        public DbSet<Trip> Trips { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //configure relationship to avoid multiple cascade paths
            modelBuilder.Entity<Trip>()
                .HasOne(t => t.FromLocation)
                .WithMany()
                .HasForeignKey(t => t.FromLocationId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Trip>()
                .HasOne(t => t.ToLocation)
                .WithMany()
                .HasForeignKey(t => t.ToLocationId)
                .OnDelete(DeleteBehavior.Restrict);


            modelBuilder.Entity<Location>().HasData(
                new Location { Id = 1, Name = "Kuala Lumpur" },
                new Location { Id = 2, Name = "Penang" },
                new Location { Id = 3, Name = "Johor Bahru" },
                new Location { Id = 4, Name = "Ipoh" },
                new Location { Id = 5, Name = "Selangor" },
                new Location { Id = 6, Name = "Putrajaya" },
                new Location { Id = 7, Name = "Melaka" },
                new Location { Id = 8, Name = "Seremban" },
                new Location { Id = 9, Name = "Alor Setar" },
                new Location { Id = 10, Name = "Kangar" },
                new Location { Id = 11, Name = "Kota Bharu" },
                new Location { Id = 12, Name = "Kuala Terengganu" },
                new Location { Id = 13, Name = "Kuantan" },
                new Location { Id = 14, Name = "Temerloh" }
            );

            modelBuilder.Entity<Trip>().HasData(
                new Trip
                {
                    Id = 1,
                    OperatorName = "Kesatuan",
                    SeatType = "Standard",
                    FromLocationId = 1,
                    ToLocationId = 2,
                    DepartureDate = new DateTime(2025, 8, 22, 9, 0, 0),
                    AvailableSeats = 40,
                    Price = 63m
                }, // KL → Penang (Kesatuan)

                new Trip
                {
                    Id = 2,
                    OperatorName = "Maraliner",
                    SeatType = "VIP",
                    FromLocationId = 1,
                    ToLocationId = 3,
                    DepartureDate = new DateTime(2025, 8, 22, 12, 0, 0),
                    AvailableSeats = 45,
                    Price = 69m
                }, // KL → Johor Bahru

                new Trip
                {
                    Id = 3,
                    OperatorName = "Super Nice",
                    SeatType = "Standard",
                    FromLocationId = 2,
                    ToLocationId = 1,
                    DepartureDate = new DateTime(2025, 8, 22, 8, 30, 0),
                    AvailableSeats = 30,
                    Price = 65m
                }, // Penang → KL

                new Trip
                {
                    Id = 4,
                    OperatorName = "Matahari",
                    SeatType = "VIP",
                    FromLocationId = 3,
                    ToLocationId = 4,
                    DepartureDate = new DateTime(2025, 8, 22, 10, 0, 0),
                    AvailableSeats = 37,
                    Price = 80m
                }, // Johor Bahru → Ipoh

                new Trip
                {
                    Id = 5,
                    OperatorName = "Cosmic",
                    SeatType = "Standard",
                    FromLocationId = 4,
                    ToLocationId = 5,
                    DepartureDate = new DateTime(2025, 8, 23, 11, 0, 0),
                    AvailableSeats = 36,
                    Price = 74.80m
                }, // Ipoh → Selangor

                new Trip
                {
                    Id = 6,
                    OperatorName = "Utama Ekspres",
                    SeatType = "Standard",
                    FromLocationId = 5,
                    ToLocationId = 7,
                    DepartureDate = new DateTime(2025, 8, 23, 15, 0, 0),
                    AvailableSeats = 45,
                    Price = 69m
                }, // Selangor → Melaka

                new Trip
                {
                    Id = 7,
                    OperatorName = "Kesatuan",
                    SeatType = "VIP",
                    FromLocationId = 7,
                    ToLocationId = 8,
                    DepartureDate = new DateTime(2025, 8, 24, 14, 0, 0),
                    AvailableSeats = 40,
                    Price = 63m
                }, // Melaka → Seremban

                new Trip
                {
                    Id = 8,
                    OperatorName = "Maraliner",
                    SeatType = "Standard",
                    FromLocationId = 8,
                    ToLocationId = 6,
                    DepartureDate = new DateTime(2025, 8, 24, 20, 0, 0),
                    AvailableSeats = 45,
                    Price = 69m
                }, // Seremban → Putrajaya

                new Trip
                {
                    Id = 9,
                    OperatorName = "Super Nice",
                    SeatType = "Standard",
                    FromLocationId = 9,
                    ToLocationId = 10,
                    DepartureDate = new DateTime(2025, 8, 25, 9, 0, 0),
                    AvailableSeats = 20,
                    Price = 65m
                }, // Alor Setar → Kangar

                new Trip
                {
                    Id = 10,
                    OperatorName = "Matahari",
                    SeatType = "VIP",
                    FromLocationId = 10,
                    ToLocationId = 2,
                    DepartureDate = new DateTime(2025, 8, 25, 14, 0, 0),
                    AvailableSeats = 37,
                    Price = 80m
                }, // Kangar → Penang

                new Trip
                {
                    Id = 11,
                    OperatorName = "Cosmic",
                    SeatType = "Standard",
                    FromLocationId = 11,
                    ToLocationId = 12,
                    DepartureDate = new DateTime(2025, 8, 26, 8, 0, 0),
                    AvailableSeats = 36,
                    Price = 74.80m
                }, // Kota Bharu → Kuala Terengganu

                new Trip
                {
                    Id = 12,
                    OperatorName = "Utama Ekspres",
                    SeatType = "Standard",
                    FromLocationId = 12,
                    ToLocationId = 13,
                    DepartureDate = new DateTime(2025, 8, 26, 16, 0, 0),
                    AvailableSeats = 45,
                    Price = 69m
                }, // Kuala Terengganu → Kuantan

                new Trip
                {
                    Id = 13,
                    OperatorName = "Kesatuan",
                    SeatType = "VIP",
                    FromLocationId = 13,
                    ToLocationId = 14,
                    DepartureDate = new DateTime(2025, 8, 27, 11, 0, 0),
                    AvailableSeats = 40,
                    Price = 63m
                }, // Kuantan → Temerloh

                new Trip
                {
                    Id = 14,
                    OperatorName = "Maraliner",
                    SeatType = "Standard",
                    FromLocationId = 14,
                    ToLocationId = 1,
                    DepartureDate = new DateTime(2025, 8, 27, 18, 0, 0),
                    AvailableSeats = 45,
                    Price = 69m
                }, // Temerloh → KL

                new Trip
                {
                    Id = 15,
                    OperatorName = "Super Nice",
                    SeatType = "VIP",
                    FromLocationId = 6,
                    ToLocationId = 5,
                    DepartureDate = new DateTime(2025, 8, 28, 13, 0, 0),
                    AvailableSeats = 20,
                    Price = 65m
                }, // Putrajaya → Selangor

                new Trip
                {
                    Id = 16,
                    OperatorName = "Maraliner",
                    SeatType = "Standard",
                    FromLocationId = 1,
                    ToLocationId = 2,
                    DepartureDate = new DateTime(2025, 8, 22, 12, 0, 0),
                    AvailableSeats = 10,
                    Price = 69m
                }, // KL → Penang (Maraliner)

                new Trip
                {
                    Id = 17,
                    OperatorName = "Cosmic",
                    SeatType = "VIP",
                    FromLocationId = 1,
                    ToLocationId = 2,
                    DepartureDate = new DateTime(2025, 8, 22, 15, 0, 0),
                    AvailableSeats = 25,
                    Price = 65m
                }, // KL → Penang (Cosmic)

                new Trip
                {
                    Id = 18,
                    OperatorName = "Super Nice",
                    SeatType = "Standard",
                    FromLocationId = 1,
                    ToLocationId = 3,
                    DepartureDate = new DateTime(2025, 8, 22, 10, 0, 0),
                    AvailableSeats = 15,
                    Price = 65m
                }, // KL → Johor Bahru (Super Nice)

                new Trip
                {
                    Id = 19,
                    OperatorName = "Utama Ekspres",
                    SeatType = "VIP",
                    FromLocationId = 1,
                    ToLocationId = 3,
                    DepartureDate = new DateTime(2025, 8, 22, 12, 0, 0),
                    AvailableSeats = 15,
                    Price = 69m
                }, // KL → Johor Bahru (Utama Ekspres)

                new Trip
                {
                    Id = 20,
                    OperatorName = "Cosmic",
                    SeatType = "Standard",
                    FromLocationId = 1,
                    ToLocationId = 3,
                    DepartureDate = new DateTime(2025, 8, 22, 20, 0, 0),
                    AvailableSeats = 10,
                    Price = 63m
                } // KL → Johor Bahru (Cosmic)
            );

            modelBuilder.Entity<Trip>()
            .Property(t => t.Price)
            .HasColumnType("decimal(10,2)");
        }
    }
}
