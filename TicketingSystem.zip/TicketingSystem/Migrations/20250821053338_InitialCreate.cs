﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TicketingSystem.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Locations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Locations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Trips",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FromLocationId = table.Column<int>(type: "int", nullable: false),
                    ToLocationId = table.Column<int>(type: "int", nullable: false),
                    DepartureDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    OperatorName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AvailableSeats = table.Column<int>(type: "int", nullable: false),
                    SeatType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(10,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Trips", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Trips_Locations_FromLocationId",
                        column: x => x.FromLocationId,
                        principalTable: "Locations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Trips_Locations_ToLocationId",
                        column: x => x.ToLocationId,
                        principalTable: "Locations",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Locations",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "Kuala Lumpur" },
                    { 2, "Penang" },
                    { 3, "Johor Bahru" },
                    { 4, "Ipoh" },
                    { 5, "Selangor" },
                    { 6, "Putrajaya" },
                    { 7, "Melaka" },
                    { 8, "Seremban" },
                    { 9, "Alor Setar" },
                    { 10, "Kangar" },
                    { 11, "Kota Bharu" },
                    { 12, "Kuala Terengganu" },
                    { 13, "Kuantan" },
                    { 14, "Temerloh" }
                });

            migrationBuilder.InsertData(
                table: "Trips",
                columns: new[] { "Id", "AvailableSeats", "DepartureDate", "FromLocationId", "OperatorName", "Price", "SeatType", "ToLocationId" },
                values: new object[,]
                {
                    { 1, 40, new DateTime(2025, 8, 22, 9, 0, 0, 0, DateTimeKind.Unspecified), 1, "Kesatuan", 63m, "Standard", 2 },
                    { 2, 45, new DateTime(2025, 8, 22, 12, 0, 0, 0, DateTimeKind.Unspecified), 1, "Maraliner", 69m, "VIP", 3 },
                    { 3, 30, new DateTime(2025, 8, 22, 8, 30, 0, 0, DateTimeKind.Unspecified), 2, "Super Nice", 65m, "Standard", 1 },
                    { 4, 37, new DateTime(2025, 8, 22, 10, 0, 0, 0, DateTimeKind.Unspecified), 3, "Matahari", 80m, "VIP", 4 },
                    { 5, 36, new DateTime(2025, 8, 23, 11, 0, 0, 0, DateTimeKind.Unspecified), 4, "Cosmic", 74.80m, "Standard", 5 },
                    { 6, 45, new DateTime(2025, 8, 23, 15, 0, 0, 0, DateTimeKind.Unspecified), 5, "Utama Ekspres", 69m, "Standard", 7 },
                    { 7, 40, new DateTime(2025, 8, 24, 14, 0, 0, 0, DateTimeKind.Unspecified), 7, "Kesatuan", 63m, "VIP", 8 },
                    { 8, 45, new DateTime(2025, 8, 24, 20, 0, 0, 0, DateTimeKind.Unspecified), 8, "Maraliner", 69m, "Standard", 6 },
                    { 9, 20, new DateTime(2025, 8, 25, 9, 0, 0, 0, DateTimeKind.Unspecified), 9, "Super Nice", 65m, "Standard", 10 },
                    { 10, 37, new DateTime(2025, 8, 25, 14, 0, 0, 0, DateTimeKind.Unspecified), 10, "Matahari", 80m, "VIP", 2 },
                    { 11, 36, new DateTime(2025, 8, 26, 8, 0, 0, 0, DateTimeKind.Unspecified), 11, "Cosmic", 74.80m, "Standard", 12 },
                    { 12, 45, new DateTime(2025, 8, 26, 16, 0, 0, 0, DateTimeKind.Unspecified), 12, "Utama Ekspres", 69m, "Standard", 13 },
                    { 13, 40, new DateTime(2025, 8, 27, 11, 0, 0, 0, DateTimeKind.Unspecified), 13, "Kesatuan", 63m, "VIP", 14 },
                    { 14, 45, new DateTime(2025, 8, 27, 18, 0, 0, 0, DateTimeKind.Unspecified), 14, "Maraliner", 69m, "Standard", 1 },
                    { 15, 20, new DateTime(2025, 8, 28, 13, 0, 0, 0, DateTimeKind.Unspecified), 6, "Super Nice", 65m, "VIP", 5 },
                    { 16, 10, new DateTime(2025, 8, 22, 9, 0, 0, 0, DateTimeKind.Unspecified), 1, "Maraliner", 69m, "Standard", 2 },
                    { 17, 25, new DateTime(2025, 8, 22, 9, 0, 0, 0, DateTimeKind.Unspecified), 1, "Cosmic", 65m, "VIP", 2 },
                    { 18, 15, new DateTime(2025, 8, 22, 12, 0, 0, 0, DateTimeKind.Unspecified), 1, "Super Nice", 65m, "Standard", 3 },
                    { 19, 15, new DateTime(2025, 8, 22, 12, 0, 0, 0, DateTimeKind.Unspecified), 1, "Utama Ekspres", 69m, "VIP", 3 },
                    { 20, 10, new DateTime(2025, 8, 22, 12, 0, 0, 0, DateTimeKind.Unspecified), 1, "Cosmic", 63m, "Standard", 3 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Trips_FromLocationId",
                table: "Trips",
                column: "FromLocationId");

            migrationBuilder.CreateIndex(
                name: "IX_Trips_ToLocationId",
                table: "Trips",
                column: "ToLocationId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Trips");

            migrationBuilder.DropTable(
                name: "Locations");
        }
    }
}
