﻿namespace TicketingMvc.Models;

public class Trip
{
    public int Id { get; set; }

    public int FromLocationId { get; set; }
    public int ToLocationId { get; set; }
    public DateTime DepartureDate { get; set; }
    public string OperatorName { get; set; }
    public int AvailableSeats { get; set; }
    public string SeatType { get; set; }
    public decimal Price { get; set; }

    // Navigation properties
    public Location FromLocation { get; set; } = null!;
    public Location ToLocation { get; set; } = null!;
}
