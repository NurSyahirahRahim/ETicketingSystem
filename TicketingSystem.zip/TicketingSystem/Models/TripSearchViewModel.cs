using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace TicketingMvc.Models;

public class TripSearchViewModel
{
    [Required]
    [Display(Name = "Departure")]
    public int FromLocationId { get; set; }

    [Required]
    [Display(Name = "Destination")]
    public int ToLocationId { get; set; }

    [Required]
    [DataType(DataType.Date)]
    [Display(Name = "Departure Date")]
    public DateTime DepartureDate { get; set; }

    // For dropdown binding
    public IEnumerable<SelectListItem>? Locations { get; set; }
}
