﻿namespace TicketingMvc.Models
{
    public class TripResultsViewModel
    {
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public DateTime DepartureDate { get; set; }

        public List<Trip> Trips { get; set; } = new List<Trip>();
    }
}
