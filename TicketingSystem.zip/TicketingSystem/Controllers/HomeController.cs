﻿using Microsoft.AspNetCore.Mvc;

namespace TicketingMvc.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Title"] = "Bus Trip";
            return RedirectToAction("Search", "Trips");
        }

    }
}
