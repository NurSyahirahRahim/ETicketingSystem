using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TicketingMvc.Data;
using TicketingMvc.Models;

namespace TicketingMvc.Controllers;

public class TripsController : Controller
{
    private readonly ApplicationDbContext _context;

    public TripsController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Search()
    {
        var model = new TripSearchViewModel
        {
            DepartureDate = DateTime.Today,
            Locations = _context.Locations
                .Select(l => new SelectListItem { Value = l.Id.ToString(), Text = l.Name })
                .ToList()
        };
        return View(model);
    }

    [HttpPost]
    public IActionResult Search(TripSearchViewModel model)
    {
        if (!ModelState.IsValid)
        {
            model.Locations = _context.Locations
                .Select(l => new SelectListItem { Value = l.Id.ToString(), Text = l.Name })
                .ToList();
            return View(model);
        }

        var results = _context.Trips
            .Include(t => t.FromLocation)
            .Include(t => t.ToLocation)
            .Where(t => t.FromLocationId == model.FromLocationId
                     && t.ToLocationId == model.ToLocationId
                     && t.DepartureDate.Date == model.DepartureDate.Date)
            .ToList();

        var vm = new TripResultsViewModel
        {
            FromLocation = _context.Locations.Find(model.FromLocationId)?.Name,
            ToLocation = _context.Locations.Find(model.ToLocationId)?.Name,
            DepartureDate = model.DepartureDate,
            Trips = results
        };

        Console.WriteLine($"Found {results.Count} trips.");

        return View("TripList", vm);
    }

    [HttpGet]
    public IActionResult GetLocationSuggestions(string term)
    {
        var results = _context.Locations
            .Where(l => string.IsNullOrEmpty(term) || l.Name.Contains(term))
            .Select(l => new { id = l.Id, name = l.Name })
            .Take(20)
            .ToList();

        return Json(results);
    }

    [HttpPost]
    public IActionResult Select(int tripId)
    {
        var trip = _context.Trips
            .Include(t => t.FromLocation)
            .Include(t => t.ToLocation)
            .FirstOrDefault(t => t.Id == tripId);

        if (trip == null) return NotFound();

        // Save selection to TempData or Session
        TempData["SelectedTripId"] = trip.Id;
        TempData["SelectedPrice"] = trip.Price.ToString();

        return Json(new { success = true });
    }
}
